<footer>
  <div>
    <p>This website is made by <em>Apostolos Zacharopoulos</em> for the purposes of course CS518</p>
  </div>
</footer>

</body>
</html>